QUnit.module('unitTestSample', function() {
	var formatSmallDate = (dt) => moment().format("MM/DD/YYYY");
	
	// simple unit test comparing two values
	QUnit.test("values are equal", function(assert){
		assert.equal(1,1);
	});
	
	// unit test ensuring the short date is formatted correctly
    QUnit.test('displays short date', function(assert) {
      assert.equal( formatSmallDate(new Date()), "07/29/2020", "values are equal" );
    });
    
    /** fails due to the async test ending before the responde of the getJSON operation
    QUnit.test("test for calling web service and get response in less than one sec", function(assert) {
    	
    	$.getJSON("/shockwaveSvc.xsodata/AVG_TEMP_DEVICES?$filter=DEVICE_ID eq 1")
    		.done(function(a){ 
	    		var oneSecInms = 1000;
	    		var endTime = new Date().getTime();
	    		var deltaTime = endTime - startTime;
	    		
	    		//**********************************************************************************
	    		// fails due to the async test ending before the responde of the getJSON operation
	    		// see next test for correct implementation
	    		//**********************************************************************************
	    		assert.ok(deltaTime < oneSecInms, "response took: " + deltaTime.toString() );
    		});
    });*/
    
    var startTime = new Date().getTime();
    // unit test to check if odata response returns in less than 1 second
	$.getJSON("/shockwaveSvc.xsodata/AVG_TEMP_DEVICES?$filter=DEVICE_ID eq 1")
		.done(function(oDataResponse){ 
			QUnit.test("test for calling web service and get response in less than one sec", function(assert) {
			var oneSecInms = 1000;
	    		var endTime = new Date().getTime();
	    		var deltaTime = endTime - startTime;
	    		
    			assert.ok(deltaTime < oneSecInms, "response took: " + deltaTime.toString() + " ms");
    			
    			assert.ok(oDataResponse.d.results.length > 0, "there is at least 1 record in this odata call");
    			
    			assert.deepEqual( Object.keys(oDataResponse.d.results[0]), ["ID","DEVICE_ID","TEMP","SERIAL_NUMBER","ENTRY_TMSTAMP"], "oData record matches required properties" );
		});
	});
});