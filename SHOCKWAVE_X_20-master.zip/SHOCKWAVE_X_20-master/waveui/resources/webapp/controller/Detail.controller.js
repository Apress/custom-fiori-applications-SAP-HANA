sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"shockwave/waveui/externalLibs/moment"
], function (Controller, momentjs) {
	"use strict";

	return Controller.extend("shockwave.waveui.controller.Detail", {
		onInit: function () {
			
		},
		
		onAfterRendering: function() {
			
		},
		
		handleIconTabBarSelect: function(oEvent) {
			var selectedItem = oEvent.getSource().getSelectedKey();
			var oAppModel = this.getView().getModel("appModel");
			var aDevices = oAppModel.getProperty("/AVG_TEMP_DEVICES");
			var bSelectEqZero = selectedItem === "__xmlview2--filter2";
			
			var aFilteredDevices = aDevices.filter(function(oDevice) {
				return bSelectEqZero ? oDevice.TEMP === 0 : oDevice.TEMP > 0;
			});
				
			oAppModel.setProperty("/filteredAvgTemps", aFilteredDevices);
		}
	});
});