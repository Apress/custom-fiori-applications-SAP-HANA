/* global moment:true */

sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/json/JSONModel"
], function (Controller, Filter, FilterOperator, JSONModel) {
	"use strict";

	return Controller.extend("shockwave.waveui.controller.Home", {
		onInit: function () {

		},
		
		onSearch: function(oEvent) {
			var sSearchText = oEvent.getSource().getValue();
			var oList = this.getView().byId("masterList");
			var oFilter = {};
			
			if(sSearchText !== "") {
				oFilter = new Filter("DESCRIPTION", FilterOperator.Contains, sSearchText);
			}
			else {
				oFilter = new Filter("DESCRIPTION", FilterOperator.NE , "");
			}
			var oBinding = oList.getBinding("items");
			oBinding.filter([oFilter], "Application");
		},
		
		refreshAvgTempGrid : function() {
			var oAppModel = this.getView().getModel("appModel");
			var selectedDevice = oAppModel.getProperty("/selectedItem");
			var iconTabBar = sap.ui.getCore().byId("__xmlview2--bar0");
			var bSelectEqZero = false;
			
			if(iconTabBar.getSelectedKey() === "__xmlview2--filter2"){ 
				bSelectEqZero = true;
			}
			else {
				// do something
			}
			
			$.getJSON("/shockwaveSvc.xsodata/AVG_TEMP_DEVICES?$filter=DEVICE_ID eq " + selectedDevice.ID.toString()).done(function(oResponse){ 
			
				var aDevices = oResponse.d.results;
				oAppModel.setProperty("/AVG_TEMP_DEVICES", aDevices);
				
				var aFilteredDevices = aDevices.filter(function(oDevice) {
					oDevice.ENTRY_TMSTAMP = new Date( parseInt(oDevice.ENTRY_TMSTAMP.split("(")[1].split(")")[0],10) );
					return bSelectEqZero ? oDevice.TEMP === 0 : oDevice.TEMP > 0;
				});
				
				oAppModel.setProperty("/filteredAvgTemps", aFilteredDevices);
			});
		},
		
		onListItemPressed: function(oEvent) {
			var oBindingContext = oEvent.getSource().getBindingContext("shockwave").getObject();
			var oAppModel = this.getView().getModel("appModel");
			oAppModel.setProperty("/selectedItem", oBindingContext);
			
			this.refreshAvgTempGrid();
		}
	});
});