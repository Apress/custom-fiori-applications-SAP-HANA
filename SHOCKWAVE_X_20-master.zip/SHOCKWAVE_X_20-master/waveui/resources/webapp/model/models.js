sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
		},
		
		createAppModel: function() {
			var oModel = new JSONModel({
				selectedItem: {},
				AVG_TEMP_DEVICES: [],
				filteredAvgTemps: []
			});
			oModel.setDefaultBindingMode("TwoWay");
			return oModel;
		}
	};
});