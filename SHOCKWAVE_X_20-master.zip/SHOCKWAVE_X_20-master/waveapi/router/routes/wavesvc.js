/*eslint no-console: 0, no-unused-vars: 0, no-shadow: 0, new-cap: 0*/
"use strict";
var express = require("express");
var bodyParser = require("body-parser");

function handleErrorResponse(err, res, response) {
	response.errors = [ err.message.toString() ];
	res.type("application/json")
		.status(500)
		.send(response);
}

function handleCorrectResponse(res, response) {
	res.type("application/json")
		.status(200)
		.send(response);
}

module.exports = function() {
	var router = express.Router();
	router.use(bodyParser.json());
	
    router.get("/", function(req, res) { res.send("Hello wave20!"); });
    
    router.get("/devices", function(req, res) { 
    	var response = { data: [], errors: [] };
    	var deviceId = req.params.id || null;
    	var whereClause = deviceId === null ? "" : " where ID = " + deviceId.toString();
    	
		var query = " SELECT ID, SERIAL_NUMBER, DESCRIPTION, BRAND, COST, ENTRY_TMSTAMP FROM \"wavex20.wavedb.models::CV_DEVICES\" "+	
					whereClause + " ORDER BY \"ID\" DESC; ";
		var client = req.db;
		
		client.prepare(query, 
			function(err, statement) {
				if(err) {
					handleErrorResponse(err, res, response);
					return;
				}
				statement.exec([],
					function(err, results){
						if(err) {
							handleErrorResponse(err, res, response);
							return;
						}
						else {
							response.data = results;
							handleCorrectResponse(res, response);
						}
					});
			});
    });
    
    
    return router;
};