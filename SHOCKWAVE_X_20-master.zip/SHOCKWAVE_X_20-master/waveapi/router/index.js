"use strict";

module.exports = function(app) {
	// [express] app.use mounts the middleware functions (path, functions)
	var waveSvc = require("./routes/wavesvc")();
	app.use("/wpsvc", waveSvc);
	app.use("/wpsvc/device", waveSvc);
	app.use("/wpsvc/devices", waveSvc);
};